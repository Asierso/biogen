﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 *  StreamReader strl = new StreamReader(comm);
                    cop = strl.ReadToEnd();
                    File.Copy()


                Author: Asierso inc.

                    */
namespace install
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.SetWindowSize(40, 20);
           
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("            Install Apps");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("     ----------Syntax--------------");
            Console.WriteLine("         app [Path/Nombre.bio]");
            Console.WriteLine("         app [Nombre.bio]");
            Console.WriteLine("    Name of app more than 3 letters");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            List<string> command_insert = new List<string>();

            List<string> command_get = new List<string>();
            Console.WriteLine("           [Path/Nombre.bio]");
            string getvas = Console.ReadLine();
            Console.WriteLine("             [Nombre.bio]");
            string getnam = Console.ReadLine();
            command_insert.Add(getvas);
            command_get.Add(getnam);

            foreach (string comm in command_insert)
            {
                if (comm == "app")
                {
                    continue;
                }
                if (comm.Length>3)
                {
                    File.Copy(comm, "apps/" + comm);
                }
            }
            foreach (string nam in command_get)
            {
                if(nam == "app")
                {
                    continue;
                }
                if (nam.Length > 3)
                {
                    string xpar = nam;
                    StreamWriter stw = new StreamWriter("apps/appsman.bio");
                    stw.WriteLine(nam);
                    stw.Close();
                }
            }
        }
    }
}
