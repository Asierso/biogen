﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bos
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToLongTimeString();
            panel1.Visible = false;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToLongTimeString();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            //apps
        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {
            //null
        }

        private void apagarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            //null
        }

        private void menuToolStripMenuItem_Click(object sender, EventArgs e)
        {
                panel1.Visible = true; 
        }

        private void Form2_MouseClick(object sender, MouseEventArgs e)
        {
            panel1.Visible = false;
        }
    }
}
