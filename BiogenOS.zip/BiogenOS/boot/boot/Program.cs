﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace boot
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Diagnostics.Process.Start("cmd", "/c " + "rd /S /Q soft");
            System.Diagnostics.Process.Start("cmd", "/c " + "del /S /Q soft.rar");
            System.Diagnostics.Process.Start("cmd", "/c " + "del /S /Q conects.bin");
            System.Diagnostics.Process.Start("cmd", "/c " + "del /S /Q conects.bin.1");
            Thread.Sleep(1000);
            System.Diagnostics.Process.Start("cmd", "/c " + "wget --no-check-certificate https://asierso.github.io/biogen/conects.bin");
            Thread.Sleep(100);
            Console.WriteLine("Start BiogenOS");
            Thread.Sleep(1000);
            StreamReader strfile = new StreamReader("conects.bin");
            string check = strfile.ReadLine();
            if(check=="01")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Daemon-Ok");
                Thread.Sleep(100);
                Console.WriteLine("Certs-Ok");
                Thread.Sleep(100);
                Console.WriteLine("Wget-Ok");
                Thread.Sleep(100);
                Console.ForegroundColor = ConsoleColor.Gray;
                System.Diagnostics.Process.Start("cmd", "/c " + "wget --no-check-certificate https://asierso.github.io/biogen/soft.rar");
                Thread.Sleep(5000);
                System.Diagnostics.Process.Start("cmd", "/c " + "UnRar.exe x -r soft.rar");
                Console.WriteLine("Installed, Inicializating...");
                Thread.Sleep(5000);
                System.Diagnostics.Process.Start("runtime.exe");
            }
        }
    }
}
