﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace bmd
{
    class Program
    {
        static void Main(string[] args)
        {

            string ar = "";
            if (args.Length > 0)
            {
                Console.Write("Run : ");

                // To print the command line  
                // arguments using foreach loop 
                foreach (Object obj in args)
                {
                    ar = obj.ToString();
                }


                switch(ar)
                {
                    case "-a": Console.WriteLine("Cmd Start.. Debug Mode"); System.Diagnostics.Process.Start("cmd", "/c " + "boot.exe"); break;
                    case "-b": Console.WriteLine("Deleting Biogen tmp");  System.Diagnostics.Process.Start("cmd", "/c " + "rd /Q /S soft"); System.Diagnostics.Process.Start("cmd", "/c " + "del /Q /S soft.rar"); System.Diagnostics.Process.Start("cmd", "/c " + "del /Q /S conects.bin"); System.Diagnostics.Process.Start("cmd", "/c " + "del /Q /S conects.bin.1"); break;
                    case "-c": Console.WriteLine("Operative System API By Asier Sobrino (Requires wifi)"); break;
                    case "-d": Console.WriteLine("Shutdowning PC and BiogenOS"); System.Diagnostics.Process.Start("cmd", "/c " + "shutdown -p"); break;
                    case "-e": Environment.Exit(0); break;
                    case "-f": Console.WriteLine("Reset User Config");  File.Delete("lib/users.bio"); File.Delete("lib/wbengine.bio"); File.Delete("lib/path.bio"); File.Create("lib/path.bio"); Thread.Sleep(2000);  StreamWriter strmus = new StreamWriter("lib/users.bio", true, Encoding.ASCII); string us_config = "Biogen-Default"; strmus.Write(us_config); strmus.Close(); StreamWriter strmw = new StreamWriter("lib/wbengine.bio", true, Encoding.ASCII); string wb_config = "https://www.google.com/"; strmw.Write(wb_config); strmw.Close(); break;
                    case "-g": Console.WriteLine("BSOD"); System.Diagnostics.Process.Start("error.exe"); break;
                    case "-h": Console.WriteLine("Opening Install Packages");  System.Diagnostics.Process.Start("install.exe"); break;
                            default:Environment.Exit(0);break;
                }

            }

            else
            {
                Environment.Exit(0);
            }
            
        }
    }
}
