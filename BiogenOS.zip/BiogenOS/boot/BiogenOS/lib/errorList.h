#include <iostream>
/*
                  Author:Asier
                Libs to: error lists          */

void before()
{
    system("cd ..");
    
}
void error0()
{
    system("error.exe 0x0");
}
void error1()
{
    system("error.exe 0x01");
}
void error2()
{
    system("error.exe 0x02");
}
void error3()
{
    system("error.exe 0x03");
}
void error4()
{
    system("error.exe 0x04");
}
void error5()
{
    system("error.exe 0x05");
}
void error6()
{
    system("error.exe 0x06");
}
void error7()
{
    system("error.exe 0x07");
}
void error8()
{
    system("error.exe 0x08");
}
void error9()
{
    system("error.exe 0x09");
}
void error10()
{
    system("error.exe 0x010");
}
