#include <iostream>
#include <stdlib.h>
using namespace std;
int main(int argc , char *argv[])
{
    system("color 17");
    cout<<"           Error al Iniciar"<<endl;
    cout<<"       ------------------------"<<endl;
    cout<<"   Codigo de error : ";
    cout<<argv[1]<<endl;
    cout<<"       ------------------------"<<endl;
}
